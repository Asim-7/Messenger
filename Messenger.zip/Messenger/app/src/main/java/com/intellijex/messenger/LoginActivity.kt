package com.intellijex.messenger

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btn_Login.setOnClickListener {
            val logEmail = login_Email.text.toString()
            val logPass = login_Password.text.toString()

            //Exception handling
            //if (email.isEmpty() || password.isEmpty()) return@setOnClickListener
            if (logEmail.isEmpty() || logPass.isEmpty()){
                Toast.makeText(this, "Fill all fields",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this,"Email: "+logEmail+"\nPass: "+logPass, Toast.LENGTH_SHORT).show()
            //UX Formalities
            login_Email.text.clear()
            login_Password.text.clear()
            login_Email.requestFocus()

            FirebaseAuth.getInstance().signInWithEmailAndPassword(logEmail,logPass)
                .addOnCompleteListener {  }
                .addOnFailureListener {  }
        }

        back_text.setOnClickListener {
            this.finish()
        }
    }
}
